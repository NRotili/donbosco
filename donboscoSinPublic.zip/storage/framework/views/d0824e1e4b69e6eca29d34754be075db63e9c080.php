

<?php $__env->startSection('title', 'Productos'); ?>

<?php $__env->startSection('content_header'); ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('panel.administracion.productos.create')): ?>
        <a href="<?php echo e(route('panel.administracion.productos.create')); ?>" class="btn btn-secondary float-right">Agregar
            Producto</a>

        <?php endif; ?>
      

    <h1>Listado de Productos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('panel.administracion.productos.productos-index')->html();
} elseif ($_instance->childHasBeenRendered('qwWczBt')) {
    $componentId = $_instance->getRenderedChildComponentId('qwWczBt');
    $componentTag = $_instance->getRenderedChildComponentTagName('qwWczBt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qwWczBt');
} else {
    $response = \Livewire\Livewire::mount('panel.administracion.productos.productos-index');
    $html = $response->html();
    $_instance->logRenderedChild('qwWczBt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $('.form-delete').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Confirma la acción?',
                text: "El producto quedará anulado",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Cancelar',
                confirmButtonText: 'Sí, anular!'
            }).then((result) => {
                if (result.value) {
                    this.submit();
                }
            })

        })

        $('.form-up').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Estás seguro de restablecer?',
                text: "El producto quedará dado de alta!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Cancelar',
                confirmButtonText: 'Sí, restablecer!'
            }).then((result) => {
                if (result.value) {
                    this.submit();
                }
            })

        })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/administracion/productos/index.blade.php ENDPATH**/ ?>