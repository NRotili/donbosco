<a href="/">
    <img class="img-fluid" src="<?php echo e(asset('img/logo.png')); ?>" alt="">
</a>
<?php /**PATH C:\xampp\htdocs\donbosco\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>