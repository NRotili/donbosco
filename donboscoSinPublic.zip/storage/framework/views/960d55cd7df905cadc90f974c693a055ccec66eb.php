

<?php $__env->startSection('title', 'Productos'); ?>

<?php $__env->startSection('content_header'); ?>
        <a href="<?php echo e(route('panel.administracion.ventas.index')); ?>" class="btn btn-secondary float-right">Volver</a>

      

    <h1>Ingreso de compra</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('panel.administracion.productos.productos-create')->html();
} elseif ($_instance->childHasBeenRendered('OEcMIZh')) {
    $componentId = $_instance->getRenderedChildComponentId('OEcMIZh');
    $componentTag = $_instance->getRenderedChildComponentTagName('OEcMIZh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OEcMIZh');
} else {
    $response = \Livewire\Livewire::mount('panel.administracion.productos.productos-create');
    $html = $response->html();
    $_instance->logRenderedChild('OEcMIZh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $('.form-delete').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Confirma la acción?',
                text: "La venta quedará anulada",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Cancelar',
                confirmButtonText: 'Sí, anular!'
            }).then((result) => {
                if (result.value) {
                    // Swal.fire(
                    //     'Deleted!',
                    //     'Your file has been deleted.',
                    //     'success'
                    // )
                    //Send form
                    this.submit();
                }
            })

        })

        $('.form-up').submit(function(e) {
            e.preventDefault();

            Swal.fire({
                title: 'Estás seguro de restablecer?',
                text: "La venta quedará dada de alta!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Cancelar',
                confirmButtonText: 'Sí, restablecer!'
            }).then((result) => {
                if (result.value) {
                    // Swal.fire(
                    //     'Deleted!',
                    //     'Your file has been deleted.',
                    //     'success'
                    // )
                    //Send form
                    this.submit();
                }
            })

        })

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/administracion/productos/create.blade.php ENDPATH**/ ?>