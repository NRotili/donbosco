

<?php $__env->startSection('title', 'Productos'); ?>

<?php $__env->startSection('content_header'); ?>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary float-right">Volver</a>

    <h1>Editar producto</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('panel.administracion.productos.productos-edit', ['producto' => $producto])->html();
} elseif ($_instance->childHasBeenRendered('MlTEvLx')) {
    $componentId = $_instance->getRenderedChildComponentId('MlTEvLx');
    $componentTag = $_instance->getRenderedChildComponentTagName('MlTEvLx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MlTEvLx');
} else {
    $response = \Livewire\Livewire::mount('panel.administracion.productos.productos-edit', ['producto' => $producto]);
    $html = $response->html();
    $_instance->logRenderedChild('MlTEvLx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/administracion/productos/edit.blade.php ENDPATH**/ ?>