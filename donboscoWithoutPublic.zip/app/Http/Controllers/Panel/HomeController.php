<?php

namespace App\Http\Controllers\Panel;

use App\Http\Controllers\Controller;
use App\Models\Cliente;
use Carbon\Carbon;
use Illuminate\Http\Request;

class HomeController extends Controller
{


    public function index()
    {
        $clientes = Cliente::whereMonth('fechanacimiento', Carbon::now()->format('m'))
                            ->whereDay('fechanacimiento', Carbon::now()->format('d'))->get();

        return view('panel.index', compact('clientes'));
    }
}
