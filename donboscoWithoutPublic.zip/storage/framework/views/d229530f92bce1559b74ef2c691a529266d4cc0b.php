

<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content_header'); ?>

    <a href="<?php echo e(route('panel.administracion.clientes.index')); ?>" class="btn btn-secondary float-right">VOLVER</a>


    <h1><u>Incrementar puntos a:</u> <strong><?php echo e(Str::upper($cliente->apellido) . ', ' . $cliente->nombre); ?></strong></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col col-12 col-md-6">

            <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Puntos actuales','text' => ''.e($cliente->puntos).'','icon' => 'far fa-lg fa-star'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>


        </div>

        <div class="col col-12 col-md-6">
            <div class="card">
                <div class="card-body">
                    <strong>Puntos a incrementar</strong>

                    
                        

            <?php echo Form::model($cliente, ['route' => ['panel.administracion.clientes.plusupdate', $cliente], 'method' => 'put']); ?>


                    <div class="form-row">
                        <div class="col col-8">
                            <?php echo Form::number('puntos', 0, ['class' => 'form-control', 'placeholder' => 'Puntos', 'required']); ?>


                        </div>
                        <div class="col col-4">

                            <?php echo Form::submit('Sumar puntos', ['class' => 'btn btn-primary']); ?>

                        </div>
                    </div>

                    <?php echo Form::close(); ?>


                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/administracion/clientes/plus.blade.php ENDPATH**/ ?>