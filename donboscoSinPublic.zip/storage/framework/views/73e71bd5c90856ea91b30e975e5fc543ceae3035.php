

<?php $__env->startSection('title', 'Ventas'); ?>

<?php $__env->startSection('content_header'); ?>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary float-right">Volver</a>

      
    <h1>Información de venta</h1>

    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col col-12 col-md-4">
        <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Cliente','text' => ''.e(Str::upper($venta->cliente->apellido) . ', ' . $venta->cliente->nombre).'','icon' => 'far fa-lg fa-user'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
    </div>
    <div class="col col-12 col-md-4">
        <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Fecha y hora','text' => ''.e(\Carbon\Carbon::parse($venta->created_at)->format('d/m/Y - H:i:s')).'','icon' => 'far fa-lg fa-calendar'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
    </div>
    <div class="col col-12 col-md-4">
        <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Monto total','text' => ''.e($venta->total).'','icon' => 'fas fa-lg fa-dollar-sign'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col col-12 col-md-12">

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio Costo (unidad)</th>
                            <th>Precio Vendido (unidad)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $venta->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($producto->nombre); ?>

                                </td>
                                <td><?php echo e($producto->pivot->cantidad); ?></td>
                                <td><?php echo e($producto->pivot->preciocosto); ?></td>
                                <td><?php echo e($producto->pivot->preciovendido); ?></td>
        
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

    
</div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/administracion/ventas/show.blade.php ENDPATH**/ ?>