<div class="form-row">

    <div class="form-group col-md-2">
        <?php echo Form::label('dni', 'DNI'); ?>

        <?php echo Form::text('dni', null, ['class' => 'form-control', 'placeholder' => 'DNI sin puntos']); ?>


        <?php $__errorArgs = ['dni'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-5">
        <?php echo Form::label('nombre', 'Nombre*'); ?>

        <?php echo Form::text('nombre', null, ['class' => 'form-control', 'placeholder' => 'Nombre', 'required']); ?>


        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-5">
        <?php echo Form::label('apellido', 'Apellido*'); ?>

        <?php echo Form::text('apellido', null, ['class' => 'form-control', 'placeholder' => 'Apellido', 'required']); ?>


        <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

 
</div>

<div class="form-row">

    <div class="form-group col-md-2">
        <?php echo Form::label('fechanacimiento', 'Fecha de Nacimiento*'); ?>

        <?php echo Form::date('fechanacimiento', null, ['class' => 'form-control', 'required']); ?>


        <?php $__errorArgs = ['fechanacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-2">
        <?php echo Form::label('telfijo', 'Teléfono (Fijo)'); ?>

        <?php echo Form::text('telfijo', null, ['class' => 'form-control', 'placeholder' => 'Sin 0']); ?>


        <?php $__errorArgs = ['telfijo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-2">
        <?php echo Form::label('telcelular', 'Teléfono (Celular)*'); ?>

        <?php echo Form::text('telcelular', null, ['class' => 'form-control', 'placeholder' => 'Sin 0 ni 15', 'required']); ?>


        <?php $__errorArgs = ['telcelular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-6">
        <?php echo Form::label('email', 'Email'); ?>

        <?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'Email']); ?>


        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
</div>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('panel.administracion.clientes.clients-create')->html();
} elseif ($_instance->childHasBeenRendered('Z16LKdJ')) {
    $componentId = $_instance->getRenderedChildComponentId('Z16LKdJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('Z16LKdJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Z16LKdJ');
} else {
    $response = \Livewire\Livewire::mount('panel.administracion.clientes.clients-create');
    $html = $response->html();
    $_instance->logRenderedChild('Z16LKdJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/administracion/clientes/partials/form.blade.php ENDPATH**/ ?>