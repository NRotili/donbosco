

<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content_header'); ?>
    
        <a href="<?php echo e(route('panel.configuracion.users.create')); ?>" class="btn btn-secondary float-right">Nuevo usuario</a>
    
    <h1>Lista de usuarios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
    <?php if(session('info')): ?>
        <div class="alert alert-success" >
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>
    <div class="card">

        <?php if($users->count()): ?>
           <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td width="10px">
                                    <a class="btn btn-warning btn-xs" href="<?php echo e(route('panel.configuracion.users.edit', $user)); ?>"><i
                                        class="fas fa-pen"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="card-footer">
                <?php echo e($users->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros.</strong>
            </div>
        <?php endif; ?>
        
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/configuracion/users/index.blade.php ENDPATH**/ ?>