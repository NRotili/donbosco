<div>
    <div class="form-row">

        <div class="form-group col-md-4">
            <?php echo Form::label('domicilio', 'Domicilio'); ?>

            <?php echo Form::text('domicilio', null, ['class' => 'form-control', 'placeholder' => 'Domicilio']); ?>

            
            <?php $__errorArgs = ['domicilio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group col-md-4">
            <?php echo Form::label('', 'Provincia'); ?>

            <?php echo Form::select('', $provincias, null, ['class' => 'form-control', 'wire:model'=>'province', 'placeholder'=>'Selecciona una opción']); ?>

        </div>
    
        <div class="form-group col-md-4">
            <?php echo Form::label('ciudade_id', 'Ciudad'); ?>

            <?php echo Form::select('ciudade_id', $ciudades, null, ['class' => 'form-control']); ?>

    
            <?php $__errorArgs = ['ciudade_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/livewire/panel/administracion/clientes/clients-create.blade.php ENDPATH**/ ?>