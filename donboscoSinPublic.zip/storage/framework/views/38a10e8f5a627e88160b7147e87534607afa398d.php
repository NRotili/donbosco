

<?php $__env->startSection('title', 'Productos'); ?>

<?php $__env->startSection('content_header'); ?>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary float-right ml-2">VOLVER</a>
    <a href="<?php echo e(route('panel.administracion.productos.edit', $producto->id)); ?>" class="btn btn-warning float-right"><i class="fas fa-pen"></i></a>


    <h1><u>Producto:</u> <strong><?php echo e(Str::upper($producto->nombre)); ?> - (<?php echo e($producto->codigo); ?>)</strong></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col col-12 col-md-6">
            <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Detalle del producto','text' => ''.e($producto->detalle).'','icon' => 'fas fa-lg fa-info'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
        </div>
        <div class="col col-12 col-md-3">
            <?php if($producto->combo): ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Stock','text' => 'Es combo','icon' => 'fas fa-lg fa-boxes'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Stock','text' => ''.e($producto->stock).'','icon' => 'fas fa-lg fa-boxes'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="col col-12 col-md-3">
            <?php if($producto->status): ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Status','text' => 'Publicado','icon' => 'far fa-lg fa-calendar'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Status','text' => 'Deshabilitado','icon' => 'far fa-lg fa-calendar'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php endif; ?>

        </div>
    </div>
    <div class="row">
        <div class="col col-12 col-md-3">
            <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Precio Costo','text' => ''.e($producto->preciocosto).'','icon' => 'fas fa-lg fa-dollar-sign'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>

        </div>

        <div class="col col-12 col-md-3">
            <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Precio Lista','text' => ''.e($producto->preciolista).'','icon' => 'fas fa-lg fa-dollar-sign'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
        </div>

        <div class="col col-12 col-md-3">
            <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Precio Happy Hour','text' => ''.e($producto->preciohappyhour).'','icon' => 'fas fa-lg fa-dollar-sign'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
        </div>
        <div class="col col-12 col-md-3">
            <?php if($producto->combo): ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Capital en stock','text' => 'NO CALCULA','icon' => 'fas fa-lg fa-dollar-sign'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Capital en stock','text' => ''.e($producto->preciocosto * $producto->stock).'','icon' => 'fas fa-lg fa-dollar-sign'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php endif; ?>

        </div>

    </div>


    <div class="row">
        <div class="col col-12 col-md-6">
            <div class="card">
                <div class="card-header">
                    Últimas 5 ventas
                </div>
                <div class="card-body">
                    <?php if($producto->ventas->count() > 0): ?>
                    <table class="table table-striped">
                        
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Fecha</th>
                                <th scope="col">Cantidad</th>
                                <th scope="col">Cliente</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $producto->ventas->sortByDesc('id')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><a
                                            href="<?php echo e(route('panel.administracion.ventas.show', $venta->id)); ?>"><?php echo e($venta->id); ?></a>
                                    </th>
                                    <td><?php echo e(\Carbon\Carbon::parse($venta->created_at)->format('d/m/Y - H:i')); ?></td>
                                    <td><?php echo e($venta->pivot->cantidad); ?></td>
                                    <td><a href="<?php echo e(route('panel.administracion.clientes.show', $venta->cliente->id)); ?>"><?php echo e($venta->cliente->apellido); ?>,
                                            <?php echo e($venta->cliente->nombre); ?></a></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                    <?php else: ?>
                    <strong>No hay datos para mostrar</strong>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col col-12 col-md-6">
            <div class="card">
                <div class="card-header">
                    <?php if($producto->combo): ?>
                        Contiene los siguientes productos
                    <?php else: ?>
                        Se encuentra en los siguientes combos
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Cantidad</th>
                                </tr>
                           

                        </thead>
                        <tbody>

                            <?php if($producto->combo): ?>
                                <?php $__currentLoopData = $producto->contproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contiene): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><a
                                                href="<?php echo e(route('panel.administracion.productos.show', $contiene->id)); ?>"><?php echo e($contiene->id); ?></a>
                                        </th>
                                        <td><?php echo e($contiene->nombre); ?></td>
                                        <td><?php echo e($contiene->pivot->cantidad); ?></td>
                                      
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $__currentLoopData = $producto->combos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $combo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><a
                                                href="<?php echo e(route('panel.administracion.productos.show', $combo->id)); ?>"><?php echo e($combo->id); ?></a>
                                        </th>
                                        <td><?php echo e($combo->nombre); ?></td>
                                        <td><?php echo e($combo->pivot->cantidad); ?></td>
                                      
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/administracion/productos/show.blade.php ENDPATH**/ ?>