<div>
    <?php if($selected_id > 0): ?>
        <div class="row">
            <div class="col-12 grid-margin">
                <div class="card">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card-body">
                                <h5 class="mb-4">
                                    <strong>Nombre del cliente:
                                        <?php echo e($cliente->apellido . ', ' . $cliente->nombre); ?></strong>
                                </h5>
                                <button type="button" wire:click="doAction(0)"
                                    class="btn btn-outline-secondary btn-rounded btn-icon float-right"><i
                                        class="fas fa-trash text-danger"></i></button>
                                <p class="ml-5">DNI: <strong><?php echo e($cliente->dni); ?></strong></p>
                                <p class="ml-5">Tel. Cel.: <strong><?php echo e($cliente->telcelular); ?></strong></p>
                                <p class="ml-5">Fecha Nacimiento: <strong><?php echo e($cliente->fechanacimiento); ?></strong></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card-body mb-3">
                                <div class="card-body">
                                    Puntos por esta venta: <?php echo e($puntos); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col col-12 grid-margin">
                <div class="card">
                    <div class="row">
                        <div class="col col-12 col-md-6">
                            <div class="card-body">
                                <label for="">Seleccione un cliente:</label>
                                <select wire:model.lazy="selected_id" name="" id=""
                                    class="form-control form-control-sm">
                                    <option value="">Seleccione cliente</option>
                                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cliente->id); ?>">
                                            <?php echo e($cliente->apellido . ', ' . $cliente->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['selected_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col col-12 col-md-6">
                            <div class="card">
                                
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>


    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col col-md-5">
                    <div class="form-group">
                        <label for=""><strong>Buscar producto</strong></label>
                        <select class="form-control form-control-sm" name="" id=""
                            wire:model="product_id">
                            <option value="">Seleccione producto</option>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($producto->id); ?>"><?php echo e($producto->nombre); ?> (<?php echo e($producto->stock); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col col-md-1">
                    <div class="form-group">
                        <label for=""><strong>Cantidad:</strong></label>
                        <input type="number" class="form-control form-control-sm" name="" id=""
                            wire:model.defer="cantidad">
                    </div>
                </div>
                <div class="col col-md-2">
                    <div class="form-group">
                        <label for=""><strong>Precio Lista:</strong></label>
                        <input type="number" class="form-control form-control-sm" value="" name=""
                            id="" wire:model.defer="preciolista" <?php if($isDisabledLista): ?> disabled <?php endif; ?>>
                    </div>
                </div>
                <div class="col col-md-2">
                    <div class="form-group">
                        <label for=""><strong>Precio Happy Hour:</strong></label>
                        <input type="number" class="form-control form-control-sm" name="" id=""
                            wire:model.defer="preciohappyhour" <?php if($isDisabledHH): ?> disabled <?php endif; ?> >
                    </div>
                </div>
                <div class="col col-md-1">
                <div class="form-group">
                    <label for=""><strong>HH?</strong></label>
                    <input type="checkbox" class="form-control form-control-sm" name="" id=""
                        wire:model="checkHH">
                </div>
                </div>
                <div class="col col-md-1">
                    <div class="form-group">
                        <button class="btn btn-primary btn-sm mt-4 ml-2"
                            wire:click.prevent="addProduct()">Agregar</button>
                    </div>
                </div>

            </div>
        </div>
    </div>


        


        <div class="row">
            <div class="col col-12">
                <div class="card px-2">
                    <div class="card-body">
                        <div class="container-fluid mt-1 d-flex justify-content-center w-100">
                            <div class="table-responsive w-100">
                                <table class="table">
                                    <thead>
                                        <tr class="bg-dark text-white">
                                            <th>#</th>
                                            <th>Descripción</th>
                                            <th class="text-center">Cantidad</th>
                                            <th class="text-center">Precio lista</th>
                                            <th class="text-center">Precio HH</th>
                                            <th class="text-center">Subtotal</th>
                                            <th class="text-center">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="text-center" wire:key="<?php echo e($key); ?>">
                                                <td class="text-center"> <?php echo e($key + 1); ?></td>
                                                <td class="text-left"> <?php echo e($product['name']); ?></td>
                                                <td class="text-center"> <?php echo e($product['cantidad']); ?></td>
                                                <td class="text-center"> <?php echo e($product['preciolista']); ?></td>
                                                <td class="text-center"> <?php echo e($product['preciohappyhour']); ?></td>
                                                <td class="text-center"> <?php echo e($product['itemtotal']); ?></td>
                                                <td class="text-center">
                                                    <button class="btn btn-danger btn-sm"
                                                        wire:click="removeItem(<?php echo e($key); ?>)">X</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="container-fluid mt-5 w-100">
                            <p class="text-right mb-2">Subtotal: $<?php echo e($subtotal); ?></p>
                            <p class="text-right mb-2">IVA: $0</p>
                            <h4 class="text-right mb-2">Total: $<?php echo e($total); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <div class="mb-5 mt-1 ">
        <button type="submit" class="btn btn-block btn-success" wire:click.prevent="storeOrder()">Guardar</button>
    </div>


</div>
<?php /**PATH C:\xampp\htdocs\donbosco\resources\views/livewire/panel/administracion/ventas/ventas-create.blade.php ENDPATH**/ ?>