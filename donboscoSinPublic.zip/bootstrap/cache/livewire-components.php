<?php return array (
  'panel.administracion.clientes.clients-create' => 'App\\Http\\Livewire\\Panel\\Administracion\\Clientes\\ClientsCreate',
  'panel.administracion.clientes.clients-index' => 'App\\Http\\Livewire\\Panel\\Administracion\\Clientes\\ClientsIndex',
  'panel.administracion.productos.productos-create' => 'App\\Http\\Livewire\\Panel\\Administracion\\Productos\\ProductosCreate',
  'panel.administracion.productos.productos-edit' => 'App\\Http\\Livewire\\Panel\\Administracion\\Productos\\ProductosEdit',
  'panel.administracion.productos.productos-index' => 'App\\Http\\Livewire\\Panel\\Administracion\\Productos\\ProductosIndex',
  'panel.administracion.ventas.ventas-create' => 'App\\Http\\Livewire\\Panel\\Administracion\\Ventas\\VentasCreate',
  'panel.administracion.ventas.ventas-index' => 'App\\Http\\Livewire\\Panel\\Administracion\\Ventas\\VentasIndex',
);