<div>

    <div class="card">
        <div class="card-header">
            <div class="form-row">
                <div class="form-group col-md-4">

                    <label for="codigo">Filtrar por Código</label>
                    <input id="codigo" wire:model="codigo" type="text" class="form-control"
                        placeholder="Buscar por código">

                </div>
                <div class="form-group col-md-4">

                    <label for="nombre">Filtrar por Nombre</label>
                    <input id="nombre" wire:model="nombre" type="text" class="form-control"
                        placeholder="Buscar por nombre">

                </div>
                <div class="form-group col-md-4">

                    <label for="detalle">Filtrar por Detalle</label>
                    <input id="detalle" wire:model="detalle" type="text" class="form-control"
                        placeholder="Buscar por detalle">

                </div>



            </div>


        </div>

        <?php if($productos->count()): ?>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Detalle</th>
                                <th>$ Costo</th>
                                <th>$ Lista</th>
                                <th>$ HH</th>
                                <th>Stock</th>
                                <th class="text-center"colspan="4">Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="disabled"
                                    <?php if($producto->status == 0): ?> style="text-decoration:line-through" <?php endif; ?>>
                                    <td><?php echo e($producto->nombre); ?></td>
                                    <td>
                                        <?php if($producto->detalle): ?>
                                            <?php echo e($producto->detalle); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>$<?php echo e($producto->preciocosto); ?></td>
                                    <td>$<?php echo e($producto->preciolista); ?></td>
                                    <td>$<?php echo e($producto->preciohappyhour); ?></td>
                                    <td>
                                        <?php if(!$producto->combo): ?>
                                            <?php echo e($producto->stock); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>

                                    <td width="10px">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('panel.administracion.productos.show')): ?>
                                            <a href="<?php echo e(route('panel.administracion.productos.show', $producto)); ?>"
                                                class="btn btn-info btn-xs"><i class="mx-1 fas fa-info"></i></a>
                                        <?php endif; ?>
                                    </td>


                                    <td width="10px">
                                        <?php if(!$producto->combo && $producto->status == 1): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('panel.administracion.productos.edit')): ?>
                                                <button wire:click="editStock(<?php echo e($producto->id); ?>)" data-toggle="modal"
                                                    data-target="#modalMin"
                                                    class="btn btn-secondary btn-xs <?php if($producto->status == 0): ?> disabled <?php endif; ?>"><i
                                                        class="fas fa-box-open"></i>
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>


                                    </td>

                                    <td width="10px">
                                        <?php if($producto->status == 1): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('panel.administracion.productos.edit')): ?>
                                                <a class="btn btn-warning btn-xs "
                                                    href="<?php echo e(route('panel.administracion.productos.edit', $producto)); ?>"><i
                                                        class="fas fa-pen"></i>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>


                                    </td>


                                    <td width="10px">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('panel.administracion.productos.destroy')): ?>
                                            <form class="<?php if($producto->status == 0): ?> form-up <?php else: ?> form-delete <?php endif; ?>"
                                                action="<?php echo e(route('panel.administracion.productos.destroy', $producto->id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>

                                                <button
                                                    class="btn btn-xs <?php if($producto->status == 0): ?> btn-success <?php else: ?> btn-danger <?php endif; ?>"
                                                    type="submit"><i
                                                        class="fas <?php if($producto->status == 0): ?> fa-arrow-up <?php else: ?> fa-arrow-down <?php endif; ?>"></i></button>
                                            </form>
                                        <?php endif; ?>

                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer">
                <?php echo e($productos->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros.</strong>
            </div>
        <?php endif; ?>

    </div>

    
    <?php if (isset($component)) { $__componentOriginal4f1d0be2a7bf6df59a120ed70bd9af7b4f92508e = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::class, ['id' => 'modalMin','title' => 'Stock del producto: '.e($titleModal).' ('.e($stockModal).')','staticBackdrop' => true] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:ignore.self' => true]); ?>
        <div>
            <div class="form-group">
                <label for="stock">Incrementar o decrementar stock</label>
                <input class="form-control" wire:model.defer="stock" type="number" name="stock" id="stock">
            </div>
        </div>
         <?php $__env->slot('footerSlot', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginale79ddb0df6378beefa1143d3ec5f549fbb0da806 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class, ['theme' => 'success','label' => 'Actualizar'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mr-auto','wire:click.prevent' => 'updateStock('.e($idModal).')','data-dismiss' => 'modal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale79ddb0df6378beefa1143d3ec5f549fbb0da806)): ?>
<?php $component = $__componentOriginale79ddb0df6378beefa1143d3ec5f549fbb0da806; ?>
<?php unset($__componentOriginale79ddb0df6378beefa1143d3ec5f549fbb0da806); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale79ddb0df6378beefa1143d3ec5f549fbb0da806 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class, ['theme' => 'secondary','label' => 'Cancelar'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-dismiss' => 'modal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale79ddb0df6378beefa1143d3ec5f549fbb0da806)): ?>
<?php $component = $__componentOriginale79ddb0df6378beefa1143d3ec5f549fbb0da806; ?>
<?php unset($__componentOriginale79ddb0df6378beefa1143d3ec5f549fbb0da806); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f1d0be2a7bf6df59a120ed70bd9af7b4f92508e)): ?>
<?php $component = $__componentOriginal4f1d0be2a7bf6df59a120ed70bd9af7b4f92508e; ?>
<?php unset($__componentOriginal4f1d0be2a7bf6df59a120ed70bd9af7b4f92508e); ?>
<?php endif; ?>



</div>
<?php /**PATH C:\xampp\htdocs\donbosco\resources\views/livewire/panel/administracion/productos/productos-index.blade.php ENDPATH**/ ?>