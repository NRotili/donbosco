

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col col-12 col-md-3">
            <?php if (isset($component)) { $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class, ['theme' => 'info','titleClass' => 'text-info text-uppercase','title' => 'Cumpleaños de hoy'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-callout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if($clientes->count() != 0): ?>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col col-12 mt-1">
                                <?php echo e(Str::upper($cliente->apellido)); ?>, <?php echo e($cliente->nombre); ?>

                                (<?php echo e(\Carbon\Carbon::parse($cliente->fechanacimiento)->age); ?>)
                                <a target="_blank" href="https://wa.me/+549<?php echo e($cliente->telcelular); ?>"
                                    class="btn btn-xs btn-outline-info float-right"><i class="fab fa-whatsapp"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    Sin cumpleaños
                <?php endif; ?>



             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62)): ?>
<?php $component = $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62; ?>
<?php unset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62); ?>
<?php endif; ?>
        </div>

        <div class="col col-12 col-md-3">
            <?php if (isset($component)) { $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class, ['theme' => 'info','titleClass' => 'text-info text-uppercase','title' => 'Ventas del día'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-callout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if($ventaHoy > 0): ?>
                    <strong>$ <?php echo e($ventaHoy); ?></strong>
                <?php else: ?>
                    Sin ventas
                <?php endif; ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62)): ?>
<?php $component = $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62; ?>
<?php unset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62); ?>
<?php endif; ?>
        </div>
        <div class="col col-12 col-md-3">
            <?php if (isset($component)) { $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class, ['theme' => 'info','titleClass' => 'text-info text-uppercase','title' => 'Ventas del mes'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-callout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if($ventaMes > 0): ?>
                    <strong>$ <?php echo e($ventaMes); ?></strong>
                <?php else: ?>
                    Sin ventas
                <?php endif; ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62)): ?>
<?php $component = $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62; ?>
<?php unset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62); ?>
<?php endif; ?>
        </div>
        <div class="col col-12 col-md-3">
            <?php if (isset($component)) { $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class, ['theme' => 'info','titleClass' => 'text-info text-uppercase','title' => 'Ventas del año'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-callout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if($ventaAnual > 0): ?>
                    <strong>$ <?php echo e($ventaAnual); ?></strong>
                <?php else: ?>
                    Sin ventas
                <?php endif; ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62)): ?>
<?php $component = $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62; ?>
<?php unset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62); ?>
<?php endif; ?>
        </div>
    </div>
    
    <div class="row">
        <div class="col col-12 col-md-6">
            <?php if (isset($component)) { $__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class, ['title' => 'Productos con stock bajo','theme' => 'info','icon' => 'fas fa-lg fa-arrow-down','collapsible' => 'collapsed'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if($productosBajoStock->count() > 0): ?>

                    <table class="table table-striped">
                        <thead>

                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Cantidad</th>
                            </tr>

                        </thead>
                        <tbody>


                            <?php $__currentLoopData = $productosBajoStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bajoStock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><a
                                            href="<?php echo e(route('panel.administracion.productos.show', $bajoStock->id)); ?>"><?php echo e($bajoStock->id); ?></a>
                                    </th>
                                    <td><?php echo e($bajoStock->nombre); ?></td>
                                    <td><?php echo e($bajoStock->stock); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
                <?php else: ?>
                    <strong>No hay productos para mostrar</strong>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127)): ?>
<?php $component = $__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127; ?>
<?php unset($__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127); ?>
<?php endif; ?>
        </div>

        <div class="col col-12 col-md-6">
            <?php if (isset($component)) { $__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class, ['title' => 'Productos con stock alto','theme' => 'info','icon' => 'fas fa-lg fa-arrow-up','collapsible' => 'collapsed'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if($productosAltoStock->count() > 0): ?>

                    <table class="table table-striped">
                        <thead>

                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Cantidad</th>
                            </tr>

                        </thead>
                        <tbody>


                            <?php $__currentLoopData = $productosAltoStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altoStock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><a
                                            href="<?php echo e(route('panel.administracion.productos.show', $altoStock->id)); ?>"><?php echo e($altoStock->id); ?></a>
                                    </th>
                                    <td><?php echo e($altoStock->nombre); ?></td>
                                    <td><?php echo e($altoStock->stock); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
                <?php else: ?>
                    <strong>No hay productos para mostrar</strong>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127)): ?>
<?php $component = $__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127; ?>
<?php unset($__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127); ?>
<?php endif; ?>
        </div>
    </div>

    
    <div class="row">
        <div class="col col-12 col-md-6">
            <?php if (isset($component)) { $__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class, ['title' => 'Top 5 más vendidos','theme' => 'info','icon' => 'fas fa-lg fa-shopping-cart','collapsible' => 'collapsed'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if($productosBajoStock->count() > 0): ?>

                    <table class="table table-striped">
                        <thead>

                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Cantidad</th>
                            </tr>

                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $topsales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><a
                                        href="<?php echo e(route('panel.administracion.productos.show', $top->id)); ?>"><?php echo e($top->id); ?></a>
                                </th>
                                <td><?php echo e($top->nombre); ?></td>
                                <td><?php echo e($top->total); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       
                        </tbody>

                    </table>
                <?php else: ?>
                    <strong>No hay productos para mostrar</strong>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127)): ?>
<?php $component = $__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127; ?>
<?php unset($__componentOriginal0016fe8f62f0dc60d54a606049e169e1ae7c8127); ?>
<?php endif; ?>
            
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/index.blade.php ENDPATH**/ ?>