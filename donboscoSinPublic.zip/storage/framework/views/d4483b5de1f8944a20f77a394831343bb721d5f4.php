<div>
    <?php if(session('info')): ?>
        <div class="alert alert-success">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            <div class="form-row">
                <div class="form-group col-md-4">

                    <label for="qr">Filtrar por QR</label>
                    <input id="qr" wire:model.lazy="qr" type="text" class="form-control" placeholder="Buscar por QR">

                </div>
                <div class="form-group col-md-3">

                    <label for="apellido">Filtrar por Apellido</label>
                    <input id="apellido" wire:model="apellido" type="text" class="form-control"
                        placeholder="Buscar por apellido">

                </div>
                <div class="form-group col-md-3">

                    <label for="nombre">Filtrar por Nombre</label>
                    <input id="nombre" wire:model="nombre" type="text" class="form-control"
                        placeholder="Buscar por nombre">

                </div>

                <div class="form-group col-md-2">
                    <label for="telefono">Filtrar por Celular</label>
                    <input id="telefono" wire:model="telcelular" placeholder="Buscar por celular" class="form-control">
                </div>


            </div>


        </div>

        <?php if($clientes->count()): ?>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>DNI</th>
                                <th>Apellido y Nombre</th>
                                <th>Tel. Cel.</th>
                                <th>Email</th>
                                <th class="text-center"colspan="4">Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="disabled"
                                    <?php if($cliente->habilitado == 0): ?> style="text-decoration:line-through" <?php endif; ?>>
                                    <td>
                                        <?php if($cliente->dni): ?>
                                            <?php echo e($cliente->dni); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(Str::upper($cliente->apellido) . ', ' . $cliente->nombre); ?></td>
                                    <td><?php echo e($cliente->telcelular); ?></td>
                                    <td>
                                        <?php if($cliente->email): ?>
                                            <?php echo e($cliente->email); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td width="10px">
                                        <a href="<?php echo e(route('panel.administracion.clientes.show', $cliente)); ?>"
                                            class="btn btn-info btn-xs"><i class="mx-1 fas fa-info"></i></a>
                                    </td>


                                    <td width="10px">
                                        <a class="btn btn-secondary btn-xs <?php if($cliente->habilitado == 0): ?> disabled <?php endif; ?>"
                                            href="<?php echo e(route('panel.administracion.clientes.plus', $cliente)); ?>"><i
                                                class="fas fa-plus"></i></a>

                                    </td>

                                    <td width="10px">
                                        <a class="btn btn-warning btn-xs <?php if($cliente->habilitado == 0): ?> disabled <?php endif; ?>"
                                            href="<?php echo e(route('panel.administracion.clientes.edit', $cliente)); ?>"><i
                                                class="fas fa-pen"></i>
                                        </a>


                                    </td>

                                    <td width="10px">
                                        <form class="<?php if($cliente->habilitado == 0): ?> form-up <?php else: ?> form-delete <?php endif; ?>"
                                            action="<?php echo e(route('panel.administracion.clientes.destroy', $cliente->id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>

                                            <button
                                                class="btn btn-xs <?php if($cliente->habilitado == 0): ?> btn-success <?php else: ?> btn-danger <?php endif; ?>"
                                                type="submit"><i
                                                    class="fas <?php if($cliente->habilitado == 0): ?> fa-arrow-up <?php else: ?> fa-trash <?php endif; ?>"></i></button>
                                        </form>

                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer">
                <?php echo e($clientes->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros.</strong>
            </div>
        <?php endif; ?>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\donbosco\resources\views/livewire/panel/administracion/clientes/clients-index.blade.php ENDPATH**/ ?>