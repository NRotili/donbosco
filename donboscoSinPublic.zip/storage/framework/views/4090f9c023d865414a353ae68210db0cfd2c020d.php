<div>
    <div>
        <?php if(session('info')): ?>
            <div class="alert alert-success">
                <?php echo e(session('info')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <div class="form-row">
                    <div class="form-group col-md-4">
    
                        <label for="date">Filtrar por Fecha</label>
                        <input id="date" wire:model="date" type="date" class="form-control">
    
                    </div>
                    <div class="form-group col-md-3">
    
                        <label for="apellido">Filtrar por Apellido</label>
                        <input id="apellido" wire:model="apellido" type="text" class="form-control"
                            placeholder="Buscar por apellido">
                            <?php echo e($apellido); ?>

    
                    </div>
                    <div class="form-group col-md-3">
    
                        <label for="nombre">Filtrar por Nombre</label>
                        <input id="nombre" wire:model="nombre" type="text" class="form-control"
                            placeholder="Buscar por nombre">
    
                    </div>
    
                    <div class="form-group col-md-2">
                        <label for="telefono">Filtrar por Celular</label>
                        <input id="telefono" wire:model="telcelular" placeholder="Buscar por celular" class="form-control">
                    </div>
    
                </div>
    
            </div>
    
            <?php if($ventas->count()): ?>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Cant. Prod.</th>
                                    <th>Monto</th>
                                    <th>Cliente</th>
                                    <th class="text-center"colspan="3">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="disabled"
                                        <?php if($venta->status == 0): ?> style="text-decoration:line-through" <?php endif; ?>>
                                        <td>
                                            <?php echo e(\Carbon\Carbon::parse($venta->created_at)->format('d/m/Y')); ?>

                                        </td>
                                    
                                        <td><?php echo e($venta->productos()->sum('cantidad')); ?></td>
                                        <td><?php echo e($venta->total); ?></td>
                                        <td><?php echo e(Str::upper($venta->cliente->apellido)); ?>, <?php echo e($venta->cliente->nombre); ?></td>
 
                                        <td width="10px">
                                            <a href="<?php echo e(route('panel.administracion.ventas.show', $venta)); ?>"
                                                class="btn btn-info btn-xs"><i class="mx-1 fas fa-info"></i></a>
                                        </td>
    
                                      
    
                                        <td width="10px">
                                            <form class="<?php if($venta->status == 0): ?> form-up <?php else: ?> form-delete <?php endif; ?>"
                                                action="<?php echo e(route('panel.administracion.clientes.destroy', $venta->id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
    
                                                <button
                                                    class="btn btn-xs <?php if($venta->status == 0): ?> btn-success <?php else: ?> btn-danger <?php endif; ?>"
                                                    type="submit"><i
                                                        class="fas <?php if($venta->status == 0): ?> fa-arrow-up <?php else: ?> fa-trash <?php endif; ?>"></i></button>
                                            </form>
    
                                        </td>
    
    
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
    
                <div class="card-footer">
                    <?php echo e($ventas->links()); ?>

                </div>
            <?php else: ?>
                <div class="card-body">
                    <strong>No hay registros.</strong>
                </div>
            <?php endif; ?>
    
        </div>
    
    </div>
    
</div>
<?php /**PATH C:\xampp\htdocs\donbosco\resources\views/livewire/panel/administracion/ventas/ventas-index.blade.php ENDPATH**/ ?>