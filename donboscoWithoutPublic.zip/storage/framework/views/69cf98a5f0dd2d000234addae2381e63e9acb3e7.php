

<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content_header'); ?>

    <a href="<?php echo e(route('panel.administracion.clientes.index')); ?>" class="btn btn-secondary float-right">VOLVER</a>


    <h1><u>Cliente:</u> <strong><?php echo e(Str::upper($cliente->apellido) . ', ' . $cliente->nombre); ?></strong></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col col-12 col-md-4">
            <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Apellido y Nombre','text' => ''.e(Str::upper($cliente->apellido) . ', ' . $cliente->nombre).'','icon' => 'far fa-lg fa-user'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
        </div>
        <div class="col col-12 col-md-4">
            <?php if($cliente->dni): ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'DNI','text' => ''.e($cliente->dni).'','icon' => 'far fa-lg fa-address-card'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'DNI','text' => 'SIN DATOS','icon' => 'far fa-lg fa-address-card'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="col col-12 col-md-4">
            <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Fecha de Nacimiento','text' => ''.e(\Carbon\Carbon::parse($cliente->fechanacimiento)->format('d/m/Y')).' - '.e(\Carbon\Carbon::parse($cliente->fechanacimiento)->age).' años','icon' => 'far fa-lg fa-calendar'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col col-12 col-md-6">
            

            <?php if($cliente->domicilio): ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Domicilio','text' => ''.e($cliente->domicilio . ', ' . $cliente->ciudade->nombre . ', ' . $cliente->ciudade->provincia->nombre).'','icon' => 'fas fa-lg fa-map-pin'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Domicilio','text' => 'SIN DATOS','icon' => 'fas fa-lg fa-map-pin'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php endif; ?>


        </div>

        <div class="col col-12 col-md-6">
            <?php if($cliente->domicilio): ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Email','text' => ''.e($cliente->email).'','icon' => 'fas fa-lg fa-at'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Email','text' => 'SIN DATOS','icon' => 'fas fa-lg fa-at'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>

    </div>

    <div class="row">
        <div class="col col-12 col-md-3">
            <?php if($cliente->telfijo): ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Teléfono (Fijo)','text' => ''.e($cliente->telfijo).'','icon' => 'fas fa-lg fa-phone'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Teléfono (Fijo)','text' => 'SIN DATOS','icon' => 'fas fa-lg fa-phone'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="col col-12 col-md-3">
            <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Teléfono (Cel)','text' => ''.e($cliente->telcelular).'','icon' => 'fas fa-lg fa-mobile'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>
        </div>
        <div class="col col-12 col-md-6">
            <?php if (isset($component)) { $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class, ['title' => 'Puntos','text' => ''.e($cliente->puntos).'','icon' => 'far fa-lg fa-star'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-info-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\InfoBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2)): ?>
<?php $component = $__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2; ?>
<?php unset($__componentOriginal769f1a2e5044e7cb332aef9ba4ac2117ca577aa2); ?>
<?php endif; ?>

        </div>
    </div>

    <div class="row">
        <div class="col col-12 col-md-6">
            <div class="card">
                <div class="card-header">
                    Últimas 5 compras
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>

        <div class="col col-12 col-md-6">
            <div class="card">
                <div class="card-body text-center">
                    <img src="https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl=<?php echo e(env('APP_URL')); ?>/client/<?php echo e($cliente->qr); ?>"
                        alt="QRcode">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/administracion/clientes/show.blade.php ENDPATH**/ ?>