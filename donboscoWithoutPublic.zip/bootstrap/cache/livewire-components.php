<?php return array (
  'panel.administracion.clientes.clients-create' => 'App\\Http\\Livewire\\Panel\\Administracion\\Clientes\\ClientsCreate',
  'panel.administracion.clientes.clients-edit' => 'App\\Http\\Livewire\\Panel\\Administracion\\Clientes\\ClientsEdit',
  'panel.administracion.clientes.clients-index' => 'App\\Http\\Livewire\\Panel\\Administracion\\Clientes\\ClientsIndex',
);