<div class="form-row">
    <div class="form-group col-12 col-md-4">
        <?php echo Form::label('name', 'Nombre y Apellido'); ?>

        <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre del usuario']); ?>


        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="form-group  col-12 col-md-4">
        <?php echo Form::label('email', 'E-Mail'); ?>

        <?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el email del usuario']); ?>


        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-12 col-md-4">
        <?php echo Form::label('password', 'Contraseña'); ?>

        <?php echo Form::password('password', ['class' => 'form-control']); ?>



        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>



<h2 class="h5">Lista de roles</h2>

<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <label>
            <?php echo Form::checkbox('roles[]', $role->id, null, ['class' => 'mr-1']); ?>

            <?php echo e($role->name); ?>

        </label>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/configuracion/users/partials/form.blade.php ENDPATH**/ ?>