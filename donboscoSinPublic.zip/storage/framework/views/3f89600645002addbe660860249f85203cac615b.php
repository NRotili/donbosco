

<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content_header'); ?>

    <a href="<?php echo e(route('panel.configuraciones.sistema.index')); ?>" class="btn btn-secondary float-right">Volver</a>


    <h1>Editar datos del sistema</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('info')): ?>
<div class="alert alert-success">
    <strong><?php echo e(session('info')); ?></strong>
</div>
<?php endif; ?>

<div class="card">
<div class="card-body">
    <?php echo Form::model($sistema, ['route' => ['panel.configuraciones.sistema.update', $sistema], 'method' => 'put']); ?>


    <div class="form-row">

        <div class="form-group col-md-4">
            <?php echo Form::label('porcentajePuntos', 'Porcentaje para puntos'); ?>

            <?php echo Form::number('porcentajePuntos', null, ['class' => 'form-control']); ?>

    
            <?php $__errorArgs = ['porcentajePuntos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-md-4">
            <?php echo Form::label('stockBajo', 'Alerta de bajo stock'); ?>

            <?php echo Form::number('stockBajo', null, ['class' => 'form-control']); ?>

    
            <?php $__errorArgs = ['stockBajo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-md-4">
            <?php echo Form::label('stockAlto', 'Alerta de alto stock'); ?>

            <?php echo Form::number('stockAlto', null, ['class' => 'form-control']); ?>

    
            <?php $__errorArgs = ['stockAlto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
    
     
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <?php echo Form::label('whatsapp', 'Whatsapp'); ?>

            <?php echo Form::text('whatsapp', null, ['class' => 'form-control', 'placeholder' => 'Sin 0 ni 15']); ?>

    
            <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-md-4">
            <?php echo Form::label('facebook', 'URL del Perfil de Facebook'); ?>

            <?php echo Form::text('facebook', null, ['class' => 'form-control', 'placeholder' => 'https://...']); ?>

    
            <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-md-4">
            <?php echo Form::label('instagram', 'URL del Perfil de Instagram'); ?>

            <?php echo Form::text('instagram', null, ['class' => 'form-control', 'placeholder' => 'https://...']); ?>

    
            <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    
    <div class="form-row">
    
        <div class="form-group col-md-4">
            <?php echo Form::label('twitter', 'URL del Perfil de Twitter'); ?>

            <?php echo Form::text('twitter', null, ['class' => 'form-control', 'placeholder' => 'https://...']); ?>

    
            <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-md-4">
            <?php echo Form::label('tiktok', 'URL del Perfil de Tiktok'); ?>

            <?php echo Form::text('tiktok', null, ['class' => 'form-control', 'placeholder' => 'https://...']); ?>

    
            <?php $__errorArgs = ['tiktok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-md-4">
            <?php echo Form::label('email', 'Email'); ?>

            <?php echo Form::text('email', null, ['class' => 'form-control', 'placeholder' => '...@...']); ?>

    
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
    </div>

    <?php echo Form::submit('Actualizar sistema', ['class' => 'btn btn-primary']); ?>

    <?php echo Form::close(); ?>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donbosco\resources\views/panel/configuracion/sistema/edit.blade.php ENDPATH**/ ?>